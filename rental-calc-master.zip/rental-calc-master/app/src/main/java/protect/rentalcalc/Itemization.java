package protect.rentalcalc;

class Itemization
{
    String name;
    Integer value;

    Itemization(String name, Integer value)
    {
        this.name = name;
        this.value = value;
    }
}
